Gói bài tập Tuần 2
Chủ đề: Ứng dụng học sâu trong phát hiện mã độc

Tệp trong gói:
- Bao_cao_Tuan_2.docx: báo cáo chính, có bảng tổng hợp và danh mục Harvard.
- Bang_tong_hop_nguon.csv: bảng nguồn ở dạng CSV để mở bằng Excel.

Thông tin sinh viên:
- Họ tên: Đinh Tiến Cường
- Trường: VNU-UET
- Lớp: K70I-CS6
- Lớp học phần: UET.A12
- Email: cuongscp049@gmail.com
- Mã sinh viên: 25021659
